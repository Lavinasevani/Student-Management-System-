import tkinter as tk
from tkinter import ttk 
from tkinter import *
import pymysql
from tkinter import messagebox
#pymysql,mysql.connector,sqlite3

win = tk.Tk()
win.geometry("1200x600+0+0")
win.title("Student Window")
win.config(bg="#001C30")

title_label = tk.Label(win,text="Student Management System",font=("arial",20,"bold"),border=8,relief=tk.GROOVE,bg="#64CCC5",foreground="#001C30")
title_label.pack(side=tk.TOP,fill=tk.X)

detail_frame=tk.LabelFrame(win,text="Student's Details",font=("Arial",15),bg="#64CCC5",fg="#001C30",bd=8,relief=tk.GROOVE)
detail_frame.place(x=15,y=80,width=420,height=505)

data_frame = tk.Frame(win,bd=8,bg="#64CCC5",relief=tk.GROOVE) 
data_frame.place(x=445,y=80,width=740,height=505)
#=============Veriable============================================================================
name=tk.StringVar()
reg=tk.StringVar()
year=tk.StringVar()
section=tk.StringVar()
contact=tk.StringVar()
mail=tk.StringVar()
dob=tk.StringVar()
gender=tk.StringVar()
address=tk.StringVar()
search_com=tk.StringVar()
#==============Entry==============================================================================
#Name
name_lbl = tk.Label(detail_frame,text="Name             ",font=("arial",13),bg="#DAFFFB")
name_lbl.grid(row=0,column=0,padx=4,pady=3)
name_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=name)
name_ent.grid(row=0,column=1,padx=4,pady=3)
#Registration No.
reg_lbl = tk.Label(detail_frame,text="Registration No",font=("arial",13),bg="#DAFFFB")
reg_lbl.grid(row=1,column=0,padx=4,pady=3)
reg_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=reg)
reg_ent.grid(row=1,column=1,padx=4,pady=3)
#year
year_lbl = tk.Label(detail_frame,text="Year               ",font=("arial",13),bg="#DAFFFB")
year_lbl.grid(row=2,column=0,padx=4,pady=3)
year_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=year)
year_ent.grid(row=2,column=1,padx=4,pady=3)
# #Section
section_lbl = tk.Label(detail_frame,text="Section            ",font=("arial",13),bg="#DAFFFB")
section_lbl.grid(row=3,column=0,padx=2,pady=3)
section_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=section)
section_ent.grid(row=3,column=1,padx=2,pady=3)
# #contact
contact_lbl = tk.Label(detail_frame,text="Contact           ",font=("arial",13),bg="#DAFFFB")
contact_lbl.grid(row=4,column=0,padx=2,pady=3)
contact_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=contact)
contact_ent.grid(row=4,column=1,padx=2,pady=3)
# #Mail ID
mail_lbl = tk.Label(detail_frame,text="Mail Id            ",font=("arial",13),bg="#DAFFFB")
mail_lbl.grid(row=5,column=0,padx=2,pady=3)
mail_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=mail)
mail_ent.grid(row=5,column=1,padx=2,pady=3)
#DoB
dob_lbl = tk.Label(detail_frame,text="Date of Birth    ",font=("arial",13),bg="#DAFFFB")
dob_lbl.grid(row=6,column=0,padx=2,pady=3)
dob_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=dob)
dob_ent.grid(row=6,column=1,padx=2,pady=3)
#Gender
gender_lbl = tk.Label(detail_frame,text="Gender            ",font=("arial",13),bg="#DAFFFB")
gender_lbl.grid(row=7,column=0,padx=2,pady=3)
gender_ent = ttk.Combobox(detail_frame,font=("arial",13),background="#64CCC5",width=27,state="readonly",textvariable=gender)
gender_ent['value']=("Male","Female","Others")
gender_ent.grid(row=7,column=1,padx=2,pady=3)
# #Address
address_lbl = tk.Label(detail_frame,text="Address          ",font=("arial",13),bg="#DAFFFB")
address_lbl.grid(row=8,column=0,padx=2,pady=3)
address_ent = tk.Entry(detail_frame,bd=5,font=("arial",13),width=28,textvariable=address)
address_ent.grid(row=8,column=1,padx=2,pady=3)

#============================================================================================#
# #=====================================Function===================================
def fetch_data():
    conn = pymysql.connect(host="localhost",user="root",password="",database="sml")
    curr=conn.cursor()
    curr.execute("SELECT*FROM data")
    rows=curr.fetchall()
    if len(rows)!=0:
        student_table.delete(*student_table.get_children())
        for row in rows:
            student_table.insert('',tk.END,values=row)
        conn.commit()
    conn.close()

def add_funn():
    if name.get() == "" or reg.get() == "" or year.get() == "" or section.get() == "" or contact.get() == "" or mail.get() == "" or dob.get() == "" or gender.get() == "" or address.get() == "":
        messagebox.showerror("Error!!", "Please fill all the details")
    else:
        conn = pymysql.connect(host="localhost", user="root", password="", database="sml")
        curr = conn.cursor()
        curr.execute("INSERT INTO data VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)", (name.get(), reg.get(), year.get(), section.get(), contact.get(), mail.get(), dob.get(), gender.get(), address.get()))
        conn.commit()
        conn.close()
        fetch_data()

def get_cursor(event):
    cursor_row=student_table.focus()
    content=student_table.item(cursor_row)
    row = content['values']
    name.set(row[0])
    reg.set(row[1])
    year.set(row[2])
    section.set(row[3])
    contact.set(row[4])
    mail.set(row[5])
    dob.set(row[6])
    gender.set(row[7])
    address.set(row[8])

def clear_fun():
    name.set("")
    reg.set("")
    year.set("")
    section.set("")
    contact.set("")
    mail.set("")
    dob.set("")
    gender.set("")
    address.set("")

def update_funn():
    conn = pymysql.connect(host="localhost", user="root", password="", database="sml")
    curr = conn.cursor()
    query = "UPDATE data SET name=%s, year=%s, section=%s, contact=%s, mail=%s, dob=%s, gender=%s, address=%s WHERE reg=%s"
    curr.execute(query, (name.get(), year.get(), section.get(), contact.get(), mail.get(), dob.get(), gender.get(), address.get(), reg.get()))
    conn.commit()
    conn.close()
    fetch_data()
    clear_fun()

def delete_funn():
    conn = pymysql.connect(host="localhost", user="root", password="", database="sml")
    curr = conn.cursor()
    query = "DELETE FROM data WHERE `reg` = %s"
    curr.execute(query, (reg.get(),))
    conn.commit()
    conn.close()
    fetch_data()
    clear_fun()

def search_data():
    selected_criteria = search_com.get()  # Get the selected search criteria
    keyword = search_keyword_entry.get()  # Get the keyword to search for

    if selected_criteria == "":  # If no criteria is selected, show an error message
        messagebox.showerror("Error", "Please select a search criteria.")
    else:
        conn = pymysql.connect(host="localhost", user="root", password="", database="sml")
        curr = conn.cursor()

        # Define the SQL query based on the selected criteria
        if selected_criteria == "Name":
            query = "SELECT * FROM data WHERE name LIKE %s"
        elif selected_criteria == "Registration No":
            query = "SELECT * FROM data WHERE reg LIKE %s"
        elif selected_criteria == "Year":
            query = "SELECT * FROM data WHERE year LIKE %s"
        elif selected_criteria == "Section":
            query = "SELECT * FROM data WHERE section LIKE %s"

        # Execute the query with the keyword as a wildcard search
        curr.execute(query, ('%' + keyword + '%',))
        rows = curr.fetchall()

        if len(rows) != 0:
            # Clear the existing data in the Treeview
            student_table.delete(*student_table.get_children())

            # Populate the Treeview with the search results
            for row in rows:
                student_table.insert('', tk.END, values=row)
            conn.commit()
        else:
            # Show a message if no results were found
            messagebox.showinfo("No Results", "No matching records found.")

        conn.close()

def show():
    fetch_data()
#===========================Button===========================================================

btn_frame = tk.Frame(detail_frame,bd=5,bg="#001C30",relief=tk.GROOVE)
btn_frame.place(x=10,y=350,width=370,height=100)

add_btn = tk.Button(btn_frame,bg="#64CCC5",text="Add",bd=4,font=("Arial",13),width=17,command=add_funn)
add_btn.grid(row=0,column=0,padx=7,pady=4)

update_btn = tk.Button(btn_frame,bg="#64CCC5",text="Update",bd=4,font=("Arial",13),width=17,command=update_funn)
update_btn.grid(row=0,column=1,padx=5,pady=4)

delete_btn = tk.Button(btn_frame,bg="#64CCC5",text="Delete",bd=4,font=("Arial",13),width=17,command=delete_funn)
delete_btn.grid(row=1,column=0,padx=7,pady=4)

clear_btn = tk.Button(btn_frame,bg="#64CCC5",text="Clear",bd=4,font=("Arial",13),width=17,command=clear_fun)
clear_btn.grid(row=1,column=1,padx=5,pady=4)
#===================================================================================================

#=========================SEARCH====================================================================

search_farme=tk.Frame(data_frame,bd=8,bg="#64CCC5",relief=tk.GROOVE)
search_farme.pack(side=tk.TOP,fill=tk.X)

search_lbl=tk.Label(search_farme,text="Search",font=("arial",14),bg="#64CCC5")
search_lbl.grid(row=0,column=0,padx=2,pady=2)

search_in = ttk.Combobox(search_farme,font=("arial",14),state="readonly",width=15,textvariable=search_com)
search_in['value']=("Name","Registration No","Year","Section",)
search_in.grid(row=0,column=1,padx=4,pady=2)

search_keyword_entry = tk.Entry(search_farme, bd=5, font=("arial", 14), width=26)
search_keyword_entry.grid(row=0, column=2, padx=2, pady=2)

Images = PhotoImage(file="bt_search (2).png")
search_btn = Button(search_farme, image=Images, bg="#64CCC5", bd=0,command= search_data)
search_btn.grid(row=0,column=3,padx=2,pady=2)

showall_btn= tk.Button(search_farme,text="Show All",font=("arial",13),width=10,bg="#64CCC5",command=show)
showall_btn.grid(row=0,column=4,padx=2,pady=2)


#====================================================================================================
#========================Data base frame=============================================================

main_frame = tk.Frame(data_frame,bd=7,relief=tk.GROOVE,bg="#64CCC5")
main_frame.pack(fill=tk.BOTH,expand=True)

y_scroll = tk.Scrollbar(main_frame,orient=tk.VERTICAL)
x_scroll = tk.Scrollbar(main_frame,orient=tk.HORIZONTAL)

student_table=ttk.Treeview(main_frame,columns=("Name","Registration No","Year","Section","Contact","Mail ID","DoB","Gender","Address"),yscrollcommand=y_scroll.set,xscrollcommand=x_scroll.set)
y_scroll.config(command=student_table.yview)
x_scroll.config(command=student_table.xview)
y_scroll.pack(side=tk.RIGHT,fill=tk.Y)
x_scroll.pack(side=tk.BOTTOM,fill=tk.X)

student_table.heading("Name",text="Name")
student_table.heading("Registration No",text="Registration No")
student_table.heading("Year",text="Year")
student_table.heading("Section",text="Section")
student_table.heading("Contact",text="Contact")
student_table.heading("Mail ID",text="Mail ID")
student_table.heading("DoB",text="DoB")
student_table.heading("Gender",text="Gender")
student_table.heading("Address",text="Address")

student_table['show']='headings'

student_table.column("Name",width=160)
student_table.column("Registration No",width=140)
student_table.column("Year",width=70)
student_table.column("Section",width=90)
student_table.column("Contact",width=150)
student_table.column("Mail ID",width=200)
student_table.column("DoB",width=100)
student_table.column("Gender",width=80)
student_table.column("Address",width=200)

student_table.pack(fill=tk.BOTH,expand=True)
#====================================================================================================
fetch_data()

student_table.bind("<ButtonRelease-1>",get_cursor)
win.mainloop()